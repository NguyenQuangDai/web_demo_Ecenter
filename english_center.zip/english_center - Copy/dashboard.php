<?php
session_start();
require_once 'includes/connect.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];
$role = $_SESSION['role'];

$user_stmt = $conn->prepare("SELECT * FROM users WHERE email = ? OR phone = ?");
$user_stmt->bind_param("ss", $username, $username);
$user_stmt->execute();
$user = $user_stmt->get_result()->fetch_assoc();
$fullname = $user['fullname'] ?? $username;

if ($role === 'student') {
    $stmt = $conn->prepare("
        SELECT c.id, c.course_name, c.course_code,
               (SELECT COUNT(*) FROM enrollments e 
                WHERE e.course_id = c.id AND e.student_id = ?) AS is_enrolled
        FROM courses c
    ");
    $stmt->bind_param("i", $user['id']);
    $stmt->execute();
    $courses = $stmt->get_result();
} elseif ($role === 'admin') {
    $courses = $conn->query("SELECT id, course_name, course_code FROM courses ORDER BY id DESC");
} elseif ($role === 'teacher') {
    $stmt = $conn->prepare("
        SELECT c.id, c.course_name, c.course_code
        FROM courses c
        JOIN course_assignments ca ON ca.course_id = c.id
        WHERE ca.teacher_id = ?
    ");
    $stmt->bind_param("i", $user['id']);
    $stmt->execute();
    $courses = $stmt->get_result();
}

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Trung Tâm Tiếng Anh</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .sidebar {
            background-color: #ffffff;
            padding: 20px;
            height: 100vh;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .course-box {
            background: white;
            border-radius: 8px;
            padding: 12px 16px;
            margin-bottom: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: 0.3s;
            cursor: pointer;
        }
        .course-box:hover { background: #f1f8ff; }
        .info-box {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .top-bar {
            background: #198754;
            color: white;
            padding: 10px 20px;
            text-align: right;
        }
        .top-bar span {
            float: left;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="top-bar">
    <span>🎓 Trung Tâm Anh Ngữ</span>
    Xin chào, <strong><?= htmlspecialchars($fullname) ?></strong> |
    <a href="logout.php" class="text-light text-decoration-underline">Đăng xuất</a>
</div>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 sidebar">
            <h5>
                <?php
                    if ($role === 'teacher') {
                        echo '📚 Khóa học được phân công';
                    } else {
                        echo '📚 Khóa học của bạn';
                    }
                ?>
            </h5>

            <?php if ($courses->num_rows > 0): ?>
                <?php if (isset($_SESSION['enroll_error'])): ?>
                    <div class="alert alert-danger">
                        <?= $_SESSION['enroll_error']; unset($_SESSION['enroll_error']); ?>
                    </div>
                <?php endif; ?>

                <?php while ($row = $courses->fetch_assoc()): ?>
                    <div class="course-box d-flex justify-content-between align-items-center" onclick="window.location.href='?course_id=<?= $row['id'] ?>'">
                        <div>
                            <strong><?= htmlspecialchars($row['course_name']) ?></strong>
                            <?php if (!empty($row['course_code'])): ?>
                                <div class="text-muted small">Mã: <?= htmlspecialchars($row['course_code']) ?></div>
                            <?php endif; ?>
                        </div>
                        <?php if (!empty($row['is_enrolled'])): ?>
                            <form method="post" action="student/unenroll.php" class="m-0">
                                <input type="hidden" name="course_id" value="<?= $row['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-danger">Huỷ đăng ký</button>
                            </form>
                        <?php else: ?>
                            <form method="post" action="student/enroll.php" class="m-0">
                                <input type="hidden" name="course_id" value="<?= $row['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-outline-primary">Đăng ký</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="text-muted">
                    <?= $role === 'admin' ? 'Chưa có khóa học nào.' : 'Chưa đăng ký khóa học nào.' ?>
                </p>
            <?php endif; ?>
        </div>

        <!-- Main Content -->
        <div class="col-md-9 p-4">
            <div class="info-box">
                <h4>🎓 Thông tin tài khoản</h4>
                <p><strong>Tên:</strong> <?= htmlspecialchars($fullname) ?></p>
                <p><strong>Email/SĐT:</strong> <?= htmlspecialchars($username) ?></p>
                <p><strong>Vai trò:</strong> <?= $role === 'admin' ? 'Quản trị viên' : ($role === 'teacher' ? 'Giảng viên' : 'Học viên') ?></p>
                <a href="edit_profile.php" class="btn btn-outline-primary">📝 Sửa thông tin</a>
            </div>

            <?php if ($role === 'admin'): ?>
                <div class="info-box">
                    <h5>🔧 Chức năng quản trị</h5>
                    <ul>
                        <li><a href="admin/manage_users.php">👥 Quản lý người dùng</a></li>
                        <li><a href="admin/manage_courses.php">📚 Quản lý khóa học</a></li>
                        <li>📊 Thống kê, báo cáo (đang phát triển)</li>
                    </ul>
                </div>

                <?php
                if (isset($_GET['course_id'])) {
                    $cid = intval($_GET['course_id']);
                    $stmt = $conn->prepare("SELECT u.fullname, u.email, u.phone FROM enrollments e JOIN users u ON e.student_id = u.id WHERE e.course_id = ?");
                    $stmt->bind_param("i", $cid);
                    $stmt->execute();
                    $students = $stmt->get_result();
                    echo '<div class="info-box">';
                    echo '<h5>👨‍🎓 Danh sách học viên đăng ký</h5>';
                    if ($students->num_rows > 0) {
                        echo '<table class="table table-bordered">';
                        echo '<thead><tr><th>Họ tên</th><th>Email</th><th>Số điện thoại</th></tr></thead><tbody>';
                        while ($s = $students->fetch_assoc()) {
                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($s['fullname']) . '</td>';
                            echo '<td>' . htmlspecialchars($s['email']) . '</td>';
                            echo '<td>' . htmlspecialchars($s['phone']) . '</td>';
                            echo '</tr>';
                        }
                        echo '</tbody></table>';
                    } else {
                        echo '<p class="text-muted">Chưa có học viên đăng ký khóa học này.</p>';
                    }
                    echo '</div>';
                }
                ?>
            <?php endif; ?>

            <?php if ($role === 'student' || $role === 'teacher'): ?>
            <div class="info-box">
                <h5>📩 Gửi phản hồi đến quản trị viên</h5>
                <form action="feedback.php" method="post">
                    <div class="mb-3">
                        <label for="feedback" class="form-label">Nội dung phản hồi</label>
                        <textarea name="feedback" id="feedback" rows="4" class="form-control" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-success">Gửi phản hồi</button>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>