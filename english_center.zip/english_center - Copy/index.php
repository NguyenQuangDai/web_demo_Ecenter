<?php include("includes/header.php"); ?>
<?php include("includes/nav.php"); ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-2 bg-white shadow-sm vh-100 p-3 sidebar">
            <div class="mb-4">
                <img src="logo.png" class="img-fluid" alt="Logo">
            </div>
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link" href="#">🏠 Trang Chủ</a></li>
                <li class="nav-item"><a class="nav-link" href="#">👤 Hồ Sơ</a></li>
                <li class="nav-item"><a class="nav-link" href="#">📚 Khóa Học</a></li>
                <li class="nav-item"><a class="nav-link" href="#">🎯 Luyện Tập</a></li>
                <li class="nav-item"><a class="nav-link" href="login.php">🔐 Đăng Nhập</a></li>
            </ul>

            <hr>
            <strong class="text-muted">KHÓA HỌC NỔI BẬT</strong>
            <ul class="nav flex-column mt-2">
                <li class="nav-item"><a class="nav-link" href="#">📘 IELTS Foundation</a></li>
                <li class="nav-item"><a class="nav-link" href="#">📗 TOEIC 650+</a></li>
                <li class="nav-item"><a class="nav-link" href="#">📕 Ngữ Pháp Căn Bản</a></li>
                <li class="nav-item"><a class="nav-link" href="#">📙 Giao Tiếp Hàng Ngày</a></li>
                <li class="nav-item"><a class="nav-link" href="#">🔊 Phát Âm Chuẩn</a></li>
                <li class="nav-item"><a class="nav-link" href="#">📖 Reading Skill</a></li>
            </ul>
        </div>

        <!-- Main content -->
        <div class="col-md-10 bg-light p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3>Chào mừng đến với Trung Tâm Anh Ngữ</h3>
                <a class="btn btn-primary" href="login.php">Đăng Nhập</a>
            </div>

            <div class="row">
                <?php
                $courses = [
                    ['IELTS Foundation', 'blue'],
                    ['TOEIC 650+', 'green'],
                    ['Ngữ Pháp Căn Bản', 'gray'],
                    ['Giao Tiếp Hàng Ngày', 'orange'],
                    ['Phát Âm Chuẩn', 'purple'],
                    ['Reading Skill', 'navy']
                ];
                foreach ($courses as $c):
                ?>
                <div class="col-md-4 mb-4">
                    <div class="card text-center">
                        <div class="card-body">
                            <h5 class="card-title text-<?= $c[1] ?>"><?= $c[0] ?></h5>
                            <a href="#" class="btn btn-outline-primary btn-sm">Xem chi tiết</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Form Test Trình Độ -->
            <div class="card mb-4">
                <div class="card-header bg-info text-white">📝 Test trình độ miễn phí</div>
                <div class="card-body">
                    <p>Bài kiểm tra đánh giá trình độ tại trung tâm được thiết kế đặc biệt để xác định chính xác năng lực hiện tại của từng học viên. Sau khi hoàn thành bài kiểm tra, trung tâm sẽ đánh giá kết quả và xây dựng lộ trình học tập cá nhân hóa, phù hợp với mục tiêu và nhu cầu riêng của mỗi học viên.</p>
                    <form>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label>Họ và tên <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Họ và Tên học viên" required>
                            </div>
                            <div class="col-md-6">
                                <label>Số điện thoại <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" placeholder="Số điện thoại của học viên" required>
                            </div>
                        </div>
                        <div class="text-end">
                            <button type="submit" class="btn btn-primary">Gửi thông tin</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Đăng ký nhận tư vấn -->
            <div class="card mb-4">
                <div class="card-header bg-warning">🎓 Đăng ký nhận tư vấn miễn phí</div>
                <div class="card-body">
                    <form>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label>Họ và tên <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Họ và Tên học viên" required>
                            </div>
                            <div class="col-md-6">
                                <label>Năm sinh <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Năm sinh của học viên" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label>Số điện thoại <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" placeholder="Số điện thoại phụ huynh" required>
                            </div>
                            <div class="col-md-6">
                                <label>Email</label>
                                <input type="email" class="form-control" placeholder="Nhập email phụ huynh">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label>Khoá học quan tâm <span class="text-danger">*</span></label>
                            <select class="form-control" required>
                                <option value="">---</option>
                                <option>Luyện thi IELTS</option>
                                <option>Luyện thi SAT</option>
                                <option>Tiếng Anh học thuật AEF (THCS)</option>
                                <option>Lớp viết chuyên / viết luận</option>
                                <option>Lớp học 1-1</option>
                                <option>Khóa học khác</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label>Nội dung cần hỗ trợ</label>
                            <textarea class="form-control" rows="4" placeholder="Địa điểm học mong muốn hoặc lời nhắn khác"></textarea>
                        </div>
                        <div class="text-end">
                            <button type="submit" class="btn btn-success">Gửi thông tin</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Hỗ trợ -->
            <div class="card">
                <div class="card-header text-danger">📢 Góc Hỗ Trợ</div>
                <div class="card-body">
                    <p>Hãy liên hệ nếu bạn cần tư vấn lộ trình học phù hợp!</p>
                    <p>💬 Zalo hỗ trợ: <a href="#">https://zalo.me/trungtamanhngu</a></p>
                    <p>📞 Hotline: 0866 832 100</p>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
