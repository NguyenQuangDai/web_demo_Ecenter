<?php
session_start();
require_once 'includes/connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phoneOrEmail = trim($_POST['phone']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? OR phone = ?");
    $stmt->bind_param("ss", $phoneOrEmail, $phoneOrEmail);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        if (password_verify($password, $user['password'])) {
            $_SESSION['username'] = $phoneOrEmail;
            $_SESSION['role'] = $user['role'];
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "❌ Mật khẩu không đúng!";
        }
    } else {
        $error = "❌ Tài khoản không tồn tại!";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng nhập</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #003a78;
            font-family: Arial, sans-serif;
        }
        .login-wrapper {
            max-width: 900px;
            margin: 60px auto;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 8px 30px rgba(0,0,0,0.2);
            display: flex;
            flex-wrap: wrap;
        }
        .login-image {
            flex: 1;
            min-width: 300px;
            background: url('https://ece.edu.vn/template/assets/images/Frame1000008916.jpg') center/cover no-repeat;
        }
        .login-form {
            flex: 1;
            min-width: 300px;
            padding: 40px;
        }
        .login-form h2 {
            font-weight: bold;
            margin-bottom: 20px;
        }
        .login-form .form-control {
            border-radius: 8px;
        }
        .login-form button {
            border-radius: 8px;
        }
        .error-text {
            color: red;
            text-align: center;
        }
        @media (max-width: 768px) {
            .login-wrapper {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

<div class="login-wrapper">

    <div class="login-image"></div>
    <div class="login-form">
        <a href="index.php" class="btn btn-link mb-3 p-0">&larr; Quay lại Dashboard</a>
        <h2>Đăng nhập</h2>
        <p class="text-muted">Tên Đăng Nhập Hoặc Email <span class="text-danger">*</span></p>

        <?php if (isset($error)): ?>
            <p class="error-text"><?= $error ?></p>
        <?php endif; ?>

        <form method="post">
            <div class="mb-3">
                <input type="text" name="phone" class="form-control" placeholder="Nhập tên đăng nhập hoặc email" required>
            </div>
            <div class="mb-3">
                <input type="password" name="password" class="form-control" placeholder="Nhập mật khẩu" required>
            </div>
            <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" value="" id="remember">
                <label class="form-check-label" for="remember">Ghi nhớ mật khẩu</label>
            </div>
            <button class="btn btn-primary w-100" type="submit">Đăng nhập</button>
        </form>

        <div class="mt-3 text-end">
            <a href="#">Quên mật khẩu</a>
        </div>
        <div class="mt-3 text-center">
            Bạn chưa có tài khoản? <a href="register.php">Đăng ký</a>
        </div>
    </div>
</div>

</body>
</html>
