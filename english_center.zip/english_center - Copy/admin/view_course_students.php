<?php
session_start();
require_once '../includes/connect.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    echo "Thiếu ID khóa học!";
    exit;
}

$course_id = intval($_GET['id']);

// Lấy thông tin khóa học
$course_stmt = $conn->prepare("SELECT course_name, course_code FROM courses WHERE id = ?");
$course_stmt->bind_param("i", $course_id);
$course_stmt->execute();
$course = $course_stmt->get_result()->fetch_assoc();

if (!$course) {
    echo "Không tìm thấy khóa học!";
    exit;
}

// Tìm kiếm và phân trang
$keyword = $_GET['keyword'] ?? '';
$keyword_like = '%' . $keyword . '%';
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 45;
$offset = ($page - 1) * $limit;

// Đếm tổng học viên khớp
if (!empty($keyword)) {
    $count_stmt = $conn->prepare("
        SELECT COUNT(*) as total FROM enrollments e
        JOIN users u ON e.student_id = u.id
        WHERE e.course_id = ? AND (u.id = ? OR u.fullname LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)
    ");
    $id_keyword = intval($keyword);
    $count_stmt->bind_param("iisss", $course_id, $id_keyword, $keyword_like, $keyword_like, $keyword_like);
} else {
    $count_stmt = $conn->prepare("SELECT COUNT(*) as total FROM enrollments WHERE course_id = ?");
    $count_stmt->bind_param("i", $course_id);
}
$count_stmt->execute();
$total_rows = $count_stmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $limit);

// Truy vấn danh sách học viên
if (!empty($keyword)) {
    $students_stmt = $conn->prepare("
        SELECT u.id, u.fullname, u.email, u.phone
        FROM enrollments e
        JOIN users u ON e.student_id = u.id
        WHERE e.course_id = ? AND (u.id = ? OR u.fullname LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)
        LIMIT ? OFFSET ?
    ");
    $id_keyword = intval($keyword);
    $students_stmt->bind_param("iisssii", $course_id, $id_keyword, $keyword_like, $keyword_like, $keyword_like, $limit, $offset);
} else {
    $students_stmt = $conn->prepare("
        SELECT u.id, u.fullname, u.email, u.phone
        FROM enrollments e
        JOIN users u ON e.student_id = u.id
        WHERE e.course_id = ?
        LIMIT ? OFFSET ?
    ");
    $students_stmt->bind_param("iii", $course_id, $limit, $offset);
}
$students_stmt->execute();
$students = $students_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Danh sách học viên - <?= htmlspecialchars($course['course_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h3>👨‍🎓 Học viên trong khóa: <?= htmlspecialchars($course['course_name']) ?> (<?= htmlspecialchars($course['course_code']) ?>)</h3>
    <a href="manage_courses.php" class="btn btn-secondary mb-3">⬅ Quay lại</a>

    <form method="get" class="mb-3 d-flex" style="max-width: 500px;">
        <input type="hidden" name="id" value="<?= $course_id ?>">
        <input type="text" name="keyword" value="<?= htmlspecialchars($keyword) ?>" class="form-control me-2" placeholder="Tìm theo ID, tên, email, SĐT...">
        <button class="btn btn-outline-success">🔍 Tìm kiếm</button>
    </form>

    <?php if ($students->num_rows > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Họ tên</th>
                    <th>Email</th>
                    <th>Số điện thoại</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($student = $students->fetch_assoc()): ?>
                    <tr>
                        <td><?= $student['id'] ?></td>
                        <td><?= htmlspecialchars($student['fullname']) ?></td>
                        <td><?= htmlspecialchars($student['email']) ?></td>
                        <td><?= htmlspecialchars($student['phone']) ?></td>
                        <td>
                            <a href="remove_student.php?course_id=<?= $course_id ?>&student_id=<?= $student['id'] ?>" 
                               class="btn btn-sm btn-danger"
                               onclick="return confirm('Bạn chắc chắn muốn xoá học viên này khỏi lớp?')">
                               🗑 Xoá
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- Phân trang -->
        <nav>
            <ul class="pagination">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?id=<?= $course_id ?>&keyword=<?= urlencode($keyword) ?>&page=<?= $i ?>">
                            <?= $i ?>
                        </a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    <?php else: ?>
        <div class="alert alert-warning">Không tìm thấy học viên nào.</div>
    <?php endif; ?>
</body>
</html>
