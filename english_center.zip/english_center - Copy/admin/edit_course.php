<?php
session_start();
require_once '../includes/connect.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id'])) {
    echo "Thiếu ID khóa học!";
    exit;
}

$course_id = intval($_GET['id']);

// Lấy thông tin khóa học hiện tại
$course_stmt = $conn->prepare("SELECT * FROM courses WHERE id = ?");
$course_stmt->bind_param("i", $course_id);
$course_stmt->execute();
$course = $course_stmt->get_result()->fetch_assoc();

if (!$course) {
    echo "Không tìm thấy khóa học!";
    exit;
}

// Xử lý cập nhật nếu có POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['course_name'];
    $code = $_POST['course_code'];
    $teacher_id = $_POST['teacher_id'] ?: null;
    $description = $_POST['description'];

    $max_students = intval($_POST['max_students']);
    $update_stmt = $conn->prepare("UPDATE courses SET course_name = ?, course_code = ?, teacher_id = ?, description = ?, max_students = ? WHERE id = ?");
    $update_stmt->bind_param("ssisii", $name, $code, $teacher_id, $description, $max_students, $course_id);

    $update_stmt->execute();

    header("Location: manage_courses.php");
    exit;
}

// Lấy danh sách giáo viên
$teachers = $conn->query("SELECT id, fullname FROM users WHERE role = 'teacher'");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa khóa học</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h2>✏️ Sửa thông tin khóa học</h2>

    <form method="post" style="max-width: 600px">
        <div class="mb-3">
        <div class="mb-3">
            <label>Tên khóa học</label>
            <input name="course_name" class="form-control" value="<?= htmlspecialchars($course['course_name']) ?>" required>
        </div>

        <div class="mb-3">
            <label>Mã khóa học</label>
            <input name="course_code" class="form-control" value="<?= htmlspecialchars($course['course_code']) ?>" required>
        </div>

        <div class="mb-3">
            <label>Giảng viên phụ trách</label>
            <select name="teacher_id" class="form-control">
                <option value="">-- Không có giảng viên --</option>
                <?php while ($t = $teachers->fetch_assoc()): ?>
                    <option value="<?= $t['id'] ?>" <?= ($t['id'] == $course['teacher_id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($t['fullname']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-3">
        <label>Giới hạn số lượng học viên</label>
            <input type="number" name="max_students" class="form-control" min="1" value="<?= $course['max_students'] ?? 30 ?>" required>
        </div>  
        <div class="mb-3">
            <label>Mô tả</label>
            <textarea name="description" class="form-control"><?= htmlspecialchars($course['description']) ?></textarea>
        </div>

        <button class="btn btn-primary" type="submit">💾 Lưu thay đổi</button>
        <a href="manage_courses.php" class="btn btn-secondary">⬅ Quay lại</a>
    </form>
</body>
</html>
