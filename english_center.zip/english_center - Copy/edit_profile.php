<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$role = $_SESSION['role'];
$username = $_SESSION['username'];
$fullname = $_SESSION['username']; // giả lập tên đầy đủ

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newname = $_POST['fullname'];
    $newpass = $_POST['password'];

    // Update session giả lập (chưa có DB)
    $_SESSION['username'] = $newname;
    $message = "Cập nhật thành công!";
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Cập nhật thông tin cá nhân</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h2>📝 Cập nhật thông tin cá nhân</h2>

    <?php if (isset($message)): ?>
        <div class="alert alert-success"><?= $message ?></div>
    <?php endif; ?>

    <form method="post" style="max-width: 400px">
        <div class="mb-3">
            <label>Họ và tên</label>
            <input type="text" name="fullname" value="<?= htmlspecialchars($fullname) ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Mật khẩu mới (nếu đổi)</label>
            <input type="password" name="password" class="form-control">
        </div>
        <button class="btn btn-primary" type="submit">Lưu thay đổi</button>
        <a href="dashboard.php" class="btn btn-secondary">⬅ Quay lại</a>
    </form>
</body>
</html>
