<?php
$host = 'localhost';         // máy chủ
$db   = 'english_center';    // tên database
$user = 'root';              // tài khoản MySQL (mặc định của XAMPP là 'root')
$pass = '(Dai2-k5)';                  // mật khẩu rỗng nếu dùng XAMPP mặc định

$conn = new mysqli($host, $user, $pass, $db);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Thiết lập charset để tránh lỗi tiếng Việt
$conn->set_charset("utf8");
?>