<?php
session_start();
require_once 'includes/connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = trim($_POST['phone']);
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $repass = $_POST['repass'];

    if (empty($phone) || empty($fullname) || empty($email) || empty($password)) {
        $error = "❌ Vui lòng nhập đầy đủ thông tin!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "❌ Email không hợp lệ!";
    } elseif ($password !== $repass) {
        $error = "❌ Mật khẩu không khớp!";
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE phone = ? OR email = ?");
        $check->bind_param("ss", $phone, $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = "❌ Số điện thoại hoặc email đã được sử dụng!";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (fullname, phone, email, password, role) VALUES (?, ?, ?, ?, 'student')");
            $stmt->bind_param("ssss", $fullname, $phone, $email, $hashed);

            if ($stmt->execute()) {
                $_SESSION['username'] = $phone;
                $_SESSION['role'] = 'student';
                header("Location: dashboard.php");
                exit;
            } else {
                $error = "❌ Đăng ký thất bại: " . $stmt->error;
            }
        }
    }
}

?>
<?php if (isset($error)): ?>
    <div class="alert alert-danger text-center"><?= $error ?></div>
<?php endif; ?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng ký tài khoản</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #002c77;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        .register-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }
        .register-form {
            padding: 30px;
        }
        .register-img {
            background: url('ic/re_logo.jpg') center center no-repeat;
            background-size: cover;
        }
        .form-title {
            font-weight: bold;
            margin-bottom: 10px;
        }
        .form-text {
            color: #888;
            font-size: 0.9rem;
            margin-bottom: 20px;
        }
        .logo {
            width: 140px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="row register-card">
                <!-- Image section -->
                <div class="col-md-6 register-img d-none d-md-block"></div>

                <!-- Form section -->
                <div class="col-md-6 bg-white register-form">
                    <a href="login.php" class="btn btn-link mb-3">&larr; Quay lại đăng nhập</a>
                    <img src="logo.png" class="logo d-block mx-auto" alt="Logo">
                    <h3 class="form-title text-center">Đăng ký tài khoản</h3>
                    <p class="form-text text-center">Điền đầy đủ thông tin bên dưới để bắt đầu học tập</p>

                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger text-center"><?= $error ?></div>
                    <?php endif; ?>

                    <form method="post">
                        <div class="mb-3">
                            <label for="fullname" class="form-label">Họ và Tên</label>
                            <input type="text" name="fullname" id="fullname" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Số điện thoại</label>
                            <input type="text" name="phone" id="phone" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" name="email" id="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Mật khẩu</label>
                            <input type="password" name="password" id="password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="repass" class="form-label">Nhập lại mật khẩu</label>
                            <input type="password" name="repass" id="repass" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Đăng ký</button>
                    </form>

                    <p class="text-center mt-3">
                        Đã có tài khoản? <a href="login.php">Đăng nhập</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
