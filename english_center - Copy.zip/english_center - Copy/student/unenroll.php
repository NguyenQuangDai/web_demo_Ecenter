<?php
session_start();
require_once(__DIR__ . '/../includes/connect.php');

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit;
}

$student_id = getStudentId($_SESSION['username'], $conn);
$course_id = intval($_POST['course_id']);

$delete_stmt = $conn->prepare("DELETE FROM enrollments WHERE student_id = ? AND course_id = ?");
$delete_stmt->bind_param("ii", $student_id, $course_id);
$delete_stmt->execute();

header("Location: ../dashboard.php");
exit;

function getStudentId($phoneOrEmail, $conn) {
    $stmt = $conn->prepare("SELECT id FROM users WHERE phone = ? OR email = ?");
    $stmt->bind_param("ss", $phoneOrEmail, $phoneOrEmail);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc()['id'];
}
