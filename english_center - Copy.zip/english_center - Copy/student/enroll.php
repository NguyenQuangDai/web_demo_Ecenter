<?php
session_start();
require_once(__DIR__ . '/../includes/connect.php');

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit;
}

$student_id = getStudentId($_SESSION['username'], $conn);
$course_id = intval($_POST['course_id']);

// Kiểm tra đã ghi danh chưa
$check = $conn->prepare("SELECT * FROM enrollments WHERE student_id = ? AND course_id = ?");
$check->bind_param("ii", $student_id, $course_id);
$check->execute();
$check_result = $check->get_result();

if ($check_result->num_rows === 0) {
    // 1. Lấy số học viên đã đăng ký và giới hạn
    $limit_stmt = $conn->prepare("
        SELECT 
            (SELECT COUNT(*) FROM enrollments WHERE course_id = ?) AS current_count,
            max_students
        FROM courses
        WHERE id = ?
    ");
    $limit_stmt->bind_param("ii", $course_id, $course_id);
    $limit_stmt->execute();
    $limit_result = $limit_stmt->get_result()->fetch_assoc();

    $current = $limit_result['current_count'];
    $max = $limit_result['max_students'];

    if ($current < $max) {
        // 2. Cho phép ghi danh nếu chưa đạt giới hạn
        $stmt = $conn->prepare("INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $student_id, $course_id);
        $stmt->execute();
    } else {
        // 3. Quá giới hạn -> chuyển hướng kèm thông báo
        $_SESSION['enroll_error'] = "❌ Khóa học đã đủ số lượng học viên.";
    }
}

header("Location: ../dashboard.php");
exit;

function getStudentId($phoneOrEmail, $conn) {
    $stmt = $conn->prepare("SELECT id FROM users WHERE phone = ? OR email = ?");
    $stmt->bind_param("ss", $phoneOrEmail, $phoneOrEmail);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc()['id'];
}
