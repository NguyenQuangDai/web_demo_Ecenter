<?php
session_start();
require_once '../includes/connect.php';

// Chỉ admin được phép truy cập
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Lấy danh sách giáo viên và sinh viên từ bảng users
$teachers = $conn->query("SELECT id, fullname, email, role FROM users WHERE role = 'teacher'");
$students = $conn->query("SELECT id, fullname, email, role FROM users WHERE role = 'student'");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý người dùng</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">

    <h2>👨‍🏫 Danh sách Giáo viên</h2>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th><th>Họ tên</th><th>Email</th><th>Vai trò</th><th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($t = $teachers->fetch_assoc()): ?>
                <tr>
                    <td><?= $t['id'] ?></td>
                    <td><?= htmlspecialchars($t['fullname']) ?></td>
                    <td><?= htmlspecialchars($t['email']) ?></td>
                    <td><?= $t['role'] ?></td>
                    <td>
                        <a href="delete_user.php?id=<?= $t['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Bạn có chắc muốn xoá giảng viên này?')">🗑 Xoá</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <a href="add_teacher.php" class="btn btn-outline-primary mb-4">➕ Thêm giảng viên</a>

    <h2>🎓 Danh sách Sinh viên</h2>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th><th>Họ tên</th><th>Email</th><th>Vai trò</th><th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($s = $students->fetch_assoc()): ?>
                <tr>
                    <td><?= $s['id'] ?></td>
                    <td><?= htmlspecialchars($s['fullname']) ?></td>
                    <td><?= htmlspecialchars($s['email']) ?></td>
                    <td><?= $s['role'] ?></td>
                    <td>
                        <a href="delete_user.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Bạn có chắc muốn xoá sinh viên này?')">🗑 Xoá</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <a href="../dashboard.php" class="btn btn-secondary mt-3">⬅ Quay lại Dashboard</a>
</body>
</html>
