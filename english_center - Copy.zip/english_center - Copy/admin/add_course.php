<?php
session_start();
require_once '../includes/connect.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Lấy danh sách giáo viên
$teacher_query = "SELECT id, fullname FROM users WHERE role = 'teacher'";
$teacher_result = $conn->query($teacher_query);

$error = '';
$max = $_POST['max_students'];
//
$stmt = $conn->prepare("INSERT INTO courses (course_name, course_code, teacher_id, description, max_students) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("ssisi", $name, $code, $teacher_id, $desc, $max);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['course_name'];
    $code = $_POST['course_code'];
    $teacher_id = $_POST['teacher_id'];
    $desc = $_POST['description'];

    // Kiểm tra trùng course_code
    $check = $conn->prepare("SELECT id FROM courses WHERE course_code = ?");
    $check->bind_param("s", $code);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $error = "❌ Mã khóa học đã được sử dụng. Vui lòng chọn mã khác.";
    } else {
        $stmt = $conn->prepare("INSERT INTO courses (course_name, course_code, teacher_id, description) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssis", $name, $code, $teacher_id, $desc);
        
        if ($stmt->execute()) {
            header("Location: manage_courses.php");
            exit;
        } else {
            $error = "❌ Lỗi thêm khóa học: " . $stmt->error;
        }
    }
}
?>


<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm khóa học</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h2>➕ Thêm khóa học mới</h2>
    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="post" style="max-width: 600px">
        <div class="mb-3">
            <label>Giới hạn học viên</label>
            <input type="number" name="max_students" class="form-control" value="30" required>
        </div>
        <div class="mb-3">
            <label>Tên khóa học</label>
            <input name="course_name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Mã khóa học</label>
            <input name="course_code" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Giảng viên phụ trách</label>
            <select name="teacher_id" class="form-control" required>
                <option value="">-- Chọn giảng viên --</option>
                <?php while ($row = $teacher_result->fetch_assoc()): ?>
                    <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['fullname']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Mô tả</label>
            <textarea name="description" class="form-control"></textarea>
        </div>
        <button class="btn btn-success">Thêm</button>
        <a href="manage_courses.php" class="btn btn-secondary">⬅ Hủy</a>
    </form>
</body>
</html>
