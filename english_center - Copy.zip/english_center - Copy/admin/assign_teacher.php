<?php
session_start();
require_once '../includes/connect.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Lấy danh sách khóa học
$courses = $conn->query("SELECT id, course_name FROM courses");

// Lấy danh sách giảng viên
$teachers = $conn->query("SELECT id, fullname FROM users WHERE role = 'teacher'");

$success = $error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course_id = $_POST['course_id'];
    $teacher_id = $_POST['teacher_id'];

    $stmt = $conn->prepare("UPDATE courses SET teacher_id = ? WHERE id = ?");
    $stmt->bind_param("ii", $teacher_id, $course_id);

    if ($stmt->execute()) {
        $success = "✅ Phân công giảng viên thành công!";
    } else {
        $error = "❌ Lỗi khi phân công: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Phân công giảng viên</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h2>📘 Phân công giảng viên vào khóa học</h2>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php elseif ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="post" style="max-width: 600px">
        <div class="mb-3">
            <label>Chọn khóa học</label>
            <select name="course_id" class="form-control" required>
                <option value="">-- Chọn --</option>
                <?php while ($c = $courses->fetch_assoc()): ?>
                    <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['course_name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Chọn giảng viên</label>
            <select name="teacher_id" class="form-control" required>
                <option value="">-- Chọn --</option>
                <?php while ($t = $teachers->fetch_assoc()): ?>
                    <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['fullname']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <button class="btn btn-success">Phân công</button>
        <a href="manage_courses.php" class="btn btn-secondary">⬅ Quay lại</a>
    </form>
</body>
</html>
