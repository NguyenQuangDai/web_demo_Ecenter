<?php
session_start();
require_once '../includes/connect.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Xử lý xóa khóa học
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM courses WHERE id=$id");
    header("Location: manage_courses.php");
    exit;
}

// Lấy danh sách khóa học cùng tên giảng viên (nếu có)
$sql = "
    SELECT c.*, u.fullname AS teacher_name,
           (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id) AS total_students
    FROM courses c
    LEFT JOIN users u ON c.teacher_id = u.id
    ORDER BY c.id DESC
";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý khóa học</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h2>📚 Quản lý Khóa học</h2>

    <a href="add_course.php" class="btn btn-success mb-3">➕ Thêm khóa học mới</a>
    <a href="assign_teacher.php" class="btn btn-outline-primary mb-3">👨‍🏫 Phân công giảng viên</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tên khóa học</th>
                <th>Mã</th>
                <th>Giảng viên phụ trách</th>
                <th>Học viên</th>
                <th>Giới hạn</th>
                <th>Hành động</th>  
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td>
                        <a href="view_course_students.php?id=<?= $row['id'] ?>">
                            <?= htmlspecialchars($row['course_name']) ?>
                        </a>
                    </td>
                    <td><?= htmlspecialchars($row['course_code']) ?></td>
                    <td><?= $row['teacher_name'] ?? '<em>Chưa phân công</em>' ?></td>
                    <td><?= $row['total_students'] ?></td>
                    <td><?= $row['max_students'] ?></td>
                    <td>
                        <a href="edit_course.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">✏️ Sửa</a>
                        <a href="?delete=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bạn chắc chắn muốn xoá khóa học này?')">🗑 Xoá</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <a href="../dashboard.php" class="btn btn-secondary mt-3">⬅ Quay lại Dashboard</a>
</body>
</html>
