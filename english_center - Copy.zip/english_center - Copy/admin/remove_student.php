<?php
session_start();
require_once '../includes/connect.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$course_id = intval($_GET['course_id']);
$student_id = intval($_GET['student_id']);

// Xóa học viên khỏi lớp
$stmt = $conn->prepare("DELETE FROM enrollments WHERE course_id = ? AND student_id = ?");
$stmt->bind_param("ii", $course_id, $student_id);
$stmt->execute();

header("Location: view_course_students.php?id=$course_id");
exit;
