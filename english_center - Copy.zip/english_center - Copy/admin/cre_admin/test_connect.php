<?php
$host = 'localhost';
$db   = 'english_center';
$user = 'root';
$pass = '(Dai2-k5)';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Lỗi kết nối: " . $conn->connect_error);
}
echo "✅ Kết nối thành công!";
