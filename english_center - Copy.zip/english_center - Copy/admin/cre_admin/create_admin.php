<?php
require_once 'includes/connect.php';

$fullname = "Admin User";
$email = "admin@";
$phone = "0999999999";
$password = password_hash("123", PASSWORD_DEFAULT);  // đổi nếu muốn
$role = "admin";

$stmt = $conn->prepare("INSERT INTO users (fullname, email, phone, password, role) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $fullname, $email, $phone, $password, $role);

if ($stmt->execute()) {
    echo "✅ Admin created successfully!";
} else {
    echo "❌ Failed: " . $stmt->error;
}
?>
