<?php
session_start();
require_once '../includes/connect.php';

// Chỉ admin được phép xóa
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Không cho phép admin tự xóa chính mình
    if ($_SESSION['user_id'] == $id) {
        die("❌ Bạn không thể tự xóa tài khoản của mình.");
    }

    // Xóa người dùng
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        header("Location: manage_users.php?deleted=1");
        exit;
    } else {
        echo "❌ Lỗi khi xóa: " . $stmt->error;
    }
} else {
    echo "❌ Thiếu ID người dùng cần xóa.";
}
?>
